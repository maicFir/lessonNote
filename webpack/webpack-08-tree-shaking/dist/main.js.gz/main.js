"use strict";(self.webpackChunkmy_webpack_project=self.webpackChunkmy_webpack_project||[]).push([["main"],{"./src/index.js":
/*!**********************!*\
  !*** ./src/index.js ***!
  \**********************/(e,s,c)=>{var n=c(/*! ./utils */"./src/utils/index.js"),o=c(/*! loadsh */"loadsh"),a=c.n(o);c(/*! ./css/index.css */"./src/css/index.css");console.log("Hello World!"),console.log((0,n.add)(1,2));var r=document.getElementsByTagName("body")[0],t=document.createElement("div");t.setAttribute("class","wrap-box"),t.innerText="wrap-box",r.appendChild(t),console.log(a().last(["Maic","Web技术学苑"]))},"./src/utils/index.js":
/*!****************************!*\
  !*** ./src/utils/index.js ***!
  \****************************/(e,s,c)=>{function n(e,s){return e+s}c.d(s,{add:()=>n})},"./src/css/index.css":
/*!***************************!*\
  !*** ./src/css/index.css ***!
  \***************************/()=>{},loadsh:
/*!********************!*\
  !*** external "_" ***!
  \********************/e=>{e.exports=_}},e=>{var s;s="./src/index.js",e(e.s=s)}]);
//# sourceMappingURL=main.js.map